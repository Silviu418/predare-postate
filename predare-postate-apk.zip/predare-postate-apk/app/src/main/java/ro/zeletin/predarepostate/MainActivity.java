package ro.zeletin.predarepostate;

import android.app.Activity;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.io.FileOutputStream;
import java.io.OutputStream;

/**
 * Predare postate — aplicația web din assets/index.html, afișată într-un WebView.
 * Pagina e servită de pe https://appassets.androidplatform.net (adresă locală, din APK),
 * ca salvarea automată (localStorage) și citirea fișierelor să meargă ca într-un browser.
 */
public class MainActivity extends Activity {

    private static final int ALEGE_FISIERE = 4153;
    private static final String ADRESA = "https://appassets.androidplatform.net/assets/index.html";

    private WebView web;
    private ValueCallback<Uri[]> fisiereCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setTextZoom(100);

        web.addJavascriptInterface(new Punte(), "AndroidBridge");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("appassets.androidplatform.net".equals(u.getHost())) return false;
                // linkurile externe se deschid în browserul telefonului
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fisiereCallback != null) fisiereCallback.onReceiveValue(null);
                fisiereCallback = callback;
                // orice tip de fișier: unele telefoane nu recunosc CSV-ul după tip
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                if (params != null && params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                }
                try {
                    startActivityForResult(Intent.createChooser(i, "Alege fișierul"), ALEGE_FISIERE);
                } catch (Exception e) {
                    fisiereCallback = null;
                    Toast.makeText(MainActivity.this, "Nu pot deschide alegerea fișierelor.", Toast.LENGTH_LONG).show();
                    return false;
                }
                return true;
            }
        });

        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else web.loadUrl(ADRESA);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != ALEGE_FISIERE || fisiereCallback == null) return;
        Uri[] rezultat = null;
        if (resultCode == RESULT_OK && data != null) {
            ClipData clip = data.getClipData();
            if (clip != null && clip.getItemCount() > 0) {
                rezultat = new Uri[clip.getItemCount()];
                for (int k = 0; k < clip.getItemCount(); k++) rezultat[k] = clip.getItemAt(k).getUri();
            } else if (data.getData() != null) {
                rezultat = new Uri[]{data.getData()};
            }
        }
        fisiereCallback.onReceiveValue(rezultat);
        fisiereCallback = null;
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (web != null) web.saveState(outState);
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    /** Primește din pagină fișierele generate (Excel, proces-verbal, lucrare) și le pune în Descărcări. */
    private class Punte {
        @JavascriptInterface
        public void saveBase64(final String numeFisier, final String tip, final String base64) {
            String nume = (numeFisier == null || numeFisier.isEmpty()) ? "fisier" : numeFisier.replaceAll("[\\\\/:*?\"<>|]", "_");
            String mime = (tip == null || tip.isEmpty()) ? "application/octet-stream" : tip;
            try {
                byte[] date = Base64.decode(base64, Base64.DEFAULT);
                Uri uri;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.MediaColumns.DISPLAY_NAME, nume);
                    v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                    v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    if (uri == null) throw new Exception("nu pot crea fișierul în Descărcări");
                    try (OutputStream o = getContentResolver().openOutputStream(uri)) {
                        if (o == null) throw new Exception("nu pot scrie fișierul");
                        o.write(date);
                    }
                } else {
                    File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    if (!dir.exists() && !dir.mkdirs()) dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                    File f = new File(dir, nume);
                    try (FileOutputStream o = new FileOutputStream(f)) { o.write(date); }
                    uri = FileProvider.getUriForFile(MainActivity.this, "ro.zeletin.predarepostate.fisiere", f);
                }
                final Uri deschide = uri;
                final String numeFinal = nume;
                final String mimeFinal = mime;
                runOnUiThread(() -> {
                    Toast.makeText(MainActivity.this, "Salvat în Descărcări: " + numeFinal, Toast.LENGTH_LONG).show();
                    // deschide fișierul cu aplicația potrivită (Excel, Word...), dacă există una
                    if (!mimeFinal.contains("json")) {
                        try {
                            Intent i = new Intent(Intent.ACTION_VIEW);
                            i.setDataAndType(deschide, mimeFinal);
                            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            startActivity(i);
                        } catch (Exception ignored) { }
                    }
                });
            } catch (final Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Nu am putut salva: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }

        /** Pagina poate întreba dacă se poate trimite pe WhatsApp (ca să arate butonul). */
        @JavascriptInterface
        public boolean canShare() { return true; }

        /**
         * Trimite fișierele generate direct pe WhatsApp (sau WhatsApp Business);
         * dacă nu e instalat, deschide lista aplicațiilor de partajare.
         * json: [{"name":"...","mime":"...","b64":"..."}, ...]
         */
        @JavascriptInterface
        public void shareFiles(final String json, final String text) {
            try {
                JSONArray arr = new JSONArray(json);
                File dir = new File(getCacheDir(), "partajare");
                if (dir.exists()) { File[] vechi = dir.listFiles(); if (vechi != null) for (File f : vechi) f.delete(); }
                if (!dir.exists() && !dir.mkdirs()) throw new Exception("nu pot pregăti fișierele");
                final ArrayList<Uri> uris = new ArrayList<>();
                String mimeComun = null;
                for (int k = 0; k < arr.length(); k++) {
                    JSONObject o = arr.getJSONObject(k);
                    String nume = o.optString("name", "fisier").replaceAll("[\\\\/:*?\"<>|]", "_");
                    String mime = o.optString("mime", "application/octet-stream");
                    File f = new File(dir, nume);
                    try (FileOutputStream out = new FileOutputStream(f)) { out.write(Base64.decode(o.getString("b64"), Base64.DEFAULT)); }
                    uris.add(FileProvider.getUriForFile(MainActivity.this, "ro.zeletin.predarepostate.fisiere", f));
                    mimeComun = (mimeComun == null || mimeComun.equals(mime)) ? mime : "*/*";
                }
                if (uris.isEmpty()) return;
                final Intent i;
                if (uris.size() == 1) {
                    i = new Intent(Intent.ACTION_SEND);
                    i.putExtra(Intent.EXTRA_STREAM, uris.get(0));
                } else {
                    i = new Intent(Intent.ACTION_SEND_MULTIPLE);
                    i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                }
                i.setType(mimeComun == null ? "*/*" : mimeComun);
                if (text != null && !text.isEmpty()) i.putExtra(Intent.EXTRA_TEXT, text);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                ClipData clip = ClipData.newRawUri("", uris.get(0));
                for (int k = 1; k < uris.size(); k++) clip.addItem(new ClipData.Item(uris.get(k)));
                i.setClipData(clip);
                runOnUiThread(() -> {
                    for (String pachet : new String[]{"com.whatsapp", "com.whatsapp.w4b"}) {
                        if (instalat(pachet)) {
                            try { Intent w = new Intent(i); w.setPackage(pachet); startActivity(w); return; } catch (Exception ignored) { }
                        }
                    }
                    try { startActivity(Intent.createChooser(i, "Trimite documentele")); }
                    catch (Exception e) { Toast.makeText(MainActivity.this, "Nu găsesc nicio aplicație pentru trimitere.", Toast.LENGTH_LONG).show(); }
                });
            } catch (final Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Nu am putut trimite: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }
    }

    private boolean instalat(String pachet) {
        try { getPackageManager().getPackageInfo(pachet, 0); return true; }
        catch (PackageManager.NameNotFoundException e) { return false; }
    }
}
